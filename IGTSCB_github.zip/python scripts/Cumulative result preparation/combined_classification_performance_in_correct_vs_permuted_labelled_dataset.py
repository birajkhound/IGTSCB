import os
import re
import sys
import math
from PIL import Image, ImageDraw, ImageFont

def clean_filename(filename):
    cleaned = filename.lower()
    cleaned = re.sub(r'\s+', ' ', cleaned).strip()
    return cleaned

def parse_filename(filename):
    cleaned = clean_filename(filename)
    
    # 1. Detect Feature Bias Type
    feature = None
    if "amino acid pair" in cleaned:
        feature = "Amino Acid Pair Usage Bias"
    elif "amino acid" in cleaned:
        feature = "Amino Acid Usage Bias"
    elif "codon pair" in cleaned:
        feature = "Codon Pair Usage Bias"
    elif "codon" in cleaned:
        feature = "Codon Usage Bias"
    elif "dinucleotide" in cleaned:
        feature = "Dinucleotide Usage Bias"
        
    # 2. Detect Label State
    state = None
    if "correct" in cleaned:
        state = "Correct Labels"
    elif "permuted" in cleaned:
        state = "Permuted Labels"
        
    # 3. Detect Comparison Group
    comparison = None
    if "mesophiles vs thermophiles" in cleaned or "mesophile vs thermophile" in cleaned:
        comparison = "Mesophiles vs Thermophiles"
    elif "psychrophiles vs mesophiles" in cleaned or "psychrophiles vs mesophile" in cleaned or "psychrophile vs mesophile" in cleaned:
        comparison = "Psychrophiles vs Mesophiles"
    elif "thermophiles vs psychrophiles" in cleaned or "thermophile vs psychrophile" in cleaned:
        comparison = "Thermophiles vs Psychrophiles"
        
    return feature, state, comparison

def draw_dashed_line(draw, x0, y0, x1, y1, fill, width=6, dash_length=25, gap_length=20):
    dx = x1 - x0
    dy = y1 - y0
    dist = math.hypot(dx, dy)
    if dist == 0:
        return
    ux = dx / dist
    uy = dy / dist
    curr_dist = 0
    while curr_dist < dist:
        seg_end = min(curr_dist + dash_length, dist)
        p0 = (x0 + curr_dist * ux, y0 + curr_dist * uy)
        p1 = (x0 + seg_end * ux, y0 + seg_end * uy)
        draw.line([p0, p1], fill=fill, width=width)
        curr_dist += dash_length + gap_length

def draw_dashed_rect(draw, x0, y0, x1, y1, fill, width=6, dash_length=25, gap_length=20):
    draw_dashed_line(draw, x0, y0, x1, y0, fill, width, dash_length, gap_length) # Top
    draw_dashed_line(draw, x1, y0, x1, y1, fill, width, dash_length, gap_length) # Right
    draw_dashed_line(draw, x1, y1, x0, y1, fill, width, dash_length, gap_length) # Bottom
    draw_dashed_line(draw, x0, y1, x0, y0, fill, width, dash_length, gap_length) # Left

def draw_rotated_text(canvas, text, font, fill, position, angle):
    """
    Draws rotated text onto the canvas.
    position is (x, y) coordinate representing the CENTER of the text.
    angle is degrees to rotate counter-clockwise (e.g. 90).
    """
    # Create a temporary single-channel mask image for text rendering
    draw_temp = ImageDraw.Draw(Image.new("L", (1, 1)))
    text_box = draw_temp.textbbox((0, 0), text, font=font)
    text_w = text_box[2] - text_box[0]
    text_h = text_box[3] - text_box[1]
    
    pad = 40
    img_txt = Image.new("RGBA", (text_w + pad*2, text_h + pad*2), (255, 255, 255, 0))
    d_txt = ImageDraw.Draw(img_txt)
    d_txt.text((pad, pad), text, fill=fill, font=font)
    
    # Rotate the text image
    rotated = img_txt.rotate(angle, expand=True, resample=Image.Resampling.BICUBIC)
    rot_w, rot_h = rotated.size
    
    # Paste rotated text onto the canvas using its alpha channel as mask
    top_left = (position[0] - rot_w // 2, position[1] - rot_h // 2)
    canvas.paste(rotated, top_left, rotated)

def combine_images_vertical_5x3(image_dir, output_png, output_pdf):
    # exact vertical order requested by the user
    features = [
        "Dinucleotide Usage Bias",
        "Codon Usage Bias",
        "Codon Pair Usage Bias",
        "Amino Acid Usage Bias",
        "Amino Acid Pair Usage Bias"
    ]
    
    # exact column order requested by the user
    comparisons = [
        "Psychrophiles vs Mesophiles",
        "Mesophiles vs Thermophiles",
        "Thermophiles vs Psychrophiles"
    ]
    
    row_letters = ["A", "B", "C", "D", "E"]
    col_numbers = ["1", "2", "3"]
    
    # Scan files in the directory
    files = [f for f in os.listdir(image_dir) if f.lower().endswith(('.tiff', '.tif', '.png', '.jpg', '.jpeg'))]
    print(f"Found {len(files)} total image files in '{image_dir}'.")
    
    # Map files: grid[feature][comparison][state] = filepath
    grid = {f: {c: {"Correct Labels": None, "Permuted Labels": None} for c in comparisons} for f in features}
    
    for f in files:
        feat, state, comp = parse_filename(f)
        if feat and state and comp:
            grid[feat][comp][state] = os.path.join(image_dir, f)

    # Reference size check
    ref_width, ref_height = 1000, 1000
    for feat in features:
        for comp in comparisons:
            for state in ["Correct Labels", "Permuted Labels"]:
                img_path = grid[feat][comp][state]
                if img_path and os.path.exists(img_path):
                    with Image.open(img_path) as img:
                        ref_width, ref_height = img.size
                        break
            if ref_width != 1000: break
        if ref_width != 1000: break
            
    print(f"Reference dimensions: {ref_width}x{ref_height}")

    cell_width = ref_width * 2
    cell_height = ref_height
    
    # Layout spacing & padding (Updated left_margin to shift grids to the left)
    left_margin = 550   # Compact left margin to shift grids left (previously 850)
    right_margin = 200
    top_margin = 400
    bottom_margin = 400
    h_spacing = 150     # horizontal gap between comparison columns
    v_spacing = 200     # vertical gap between feature rows
    inner_spacing = 30  # space between Correct & Permuted images inside the same container
    box_padding = 40    # space inside the dotted box around the images
    
    cols = len(comparisons)
    rows = len(features)
    
    total_width = left_margin + right_margin + (cols * cell_width) + ((cols - 1) * h_spacing) + (cols * inner_spacing)
    total_height = top_margin + bottom_margin + (rows * cell_height) + ((rows - 1) * v_spacing)
    
    print(f"Canvas size: {total_width}x{total_height}")
    canvas = Image.new("RGB", (total_width, total_height), "white")
    draw = ImageDraw.Draw(canvas)
    
    # Font path setup
    font_paths = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "LiberationSans-Bold.ttf",
        "LiberationSans.ttf"
    ]
    
    font_bold_file = None
    for fp in font_paths:
        if "Bold" in fp and os.path.exists(fp):
            font_bold_file = fp
            break

    try:
        font_main_title = ImageFont.truetype(font_bold_file or "arial.ttf", 110)
        font_axis_title = ImageFont.truetype(font_bold_file or "arial.ttf", 95)
        font_row_label = ImageFont.truetype(font_bold_file or "arial.ttf", 75)
        font_comp_header = ImageFont.truetype(font_bold_file or "arial.ttf", 70)
        font_state_header = ImageFont.truetype(font_bold_file or "arial.ttf", 55)
        font_badge = ImageFont.truetype(font_bold_file or "arial.ttf", 65)
    except IOError:
        print("Using fallback system fonts.")
        font_main_title = ImageFont.load_default()
        font_axis_title = ImageFont.load_default()
        font_row_label = ImageFont.load_default()
        font_comp_header = ImageFont.load_default()
        font_state_header = ImageFont.load_default()
        font_badge = ImageFont.load_default()

    # Draw Figure Title
    draw.text((total_width // 2, 100), "ROC-AUC Classification Performance Comparison", fill="black", anchor="mm", font=font_main_title)

    # Draw Column Headers
    for c_idx, comp in enumerate(comparisons):
        cell_x_start = left_margin + c_idx * (cell_width + h_spacing + inner_spacing)
        comp_center_x = cell_x_start + (cell_width // 2) + (inner_spacing // 2)
        
        header_text = f"{col_numbers[c_idx]}. {comp}"
        draw.text((comp_center_x, 230), header_text, fill="black", anchor="mm", font=font_comp_header)
        
        correct_x = cell_x_start + (ref_width // 2)
        permuted_x = cell_x_start + ref_width + inner_spacing + (ref_width // 2)
        draw.text((correct_x, 310), "Correct Labels", fill="#27AE60", anchor="mm", font=font_state_header)
        draw.text((permuted_x, 310), "Permuted Labels", fill="#C0392B", anchor="mm", font=font_state_header)

    # Draw Rows and Align Elements
    for r_idx, feat in enumerate(features):
        row_y = top_margin + r_idx * (cell_height + v_spacing)
        
        # Row label: A. Dinucleotide Usage Bias, B. Codon Usage Bias, etc.
        row_text = f"{row_letters[r_idx]}. {feat}"
        
        # DRAW ROTATED VERTICALLY: 90 degrees rotation so it appears in vertical orientation
        # Positioned closer to the grid now that left_margin is reduced
        label_x = left_margin - 180
        label_y = row_y + (cell_height // 2)
        draw_rotated_text(canvas, row_text, font_row_label, "black", (label_x, label_y), 90)
        
        for c_idx, comp in enumerate(comparisons):
            cell_x_start = left_margin + c_idx * (cell_width + h_spacing + inner_spacing)
            
            correct_x = cell_x_start
            permuted_x = cell_x_start + ref_width + inner_spacing
            
            # Draw Correct Image
            img_correct_path = grid[feat][comp]["Correct Labels"]
            if img_correct_path and os.path.exists(img_correct_path):
                with Image.open(img_correct_path) as img:
                    canvas.paste(img.resize((ref_width, ref_height)), (correct_x, row_y))
            else:
                draw.rectangle([correct_x, row_y, correct_x + ref_width, row_y + ref_height], fill="#F9EBEA", outline="#CD6155")
                draw.text((correct_x + ref_width//2, row_y + ref_height//2), "Correct Image N/A", fill="#CD6155", anchor="mm", font=font_state_header)
                
            # Draw Permuted Image
            img_permuted_path = grid[feat][comp]["Permuted Labels"]
            if img_permuted_path and os.path.exists(img_permuted_path):
                with Image.open(img_permuted_path) as img:
                    canvas.paste(img.resize((ref_width, ref_height)), (permuted_x, row_y))
            else:
                draw.rectangle([permuted_x, row_y, permuted_x + ref_width, row_y + ref_height], fill="#EAFAF1", outline="#52BE80")
                draw.text((permuted_x + ref_width//2, row_y + ref_height//2), "Permuted Image N/A", fill="#52BE80", anchor="mm", font=font_state_header)

            # Draw Dotted Container Box (Dashed rectangle around this comparison cell)
            box_x0 = cell_x_start - box_padding
            box_y0 = row_y - box_padding
            box_x1 = cell_x_start + cell_width + inner_spacing + box_padding
            box_y1 = row_y + ref_height + box_padding
            draw_dashed_rect(draw, box_x0, box_y0, box_x1, box_y1, fill="#34495E", width=5, dash_length=25, gap_length=15)
            
            # Single Label Tag Badge: e.g. A1, A2, B3...
            tag_text = f"{row_letters[r_idx]}{col_numbers[c_idx]}"
            
            # White rounded-rectangle badge with a border
            badge_x0 = box_x0 + 30
            badge_y0 = box_y0 + 30
            badge_w = 140
            badge_h = 100
            
            draw.rounded_rectangle([badge_x0, badge_y0, badge_x0 + badge_w, badge_y0 + badge_h], radius=15, fill="white", outline="#34495E", width=5)
            draw.text((badge_x0 + badge_w // 2, badge_y0 + badge_h // 2), tag_text, fill="black", anchor="mm", font=font_badge)

    # Global horizontal X-axis Label
    x_label_y = total_height - 120
    draw.text((total_width // 2, x_label_y), "False Positive Rate", fill="black", anchor="mm", font=font_axis_title)
    
    # Global vertical Y-axis Label
    y_label_x = 100
    draw_rotated_text(canvas, "True Positive Rate", font_axis_title, "black", (y_label_x, total_height // 2), 90)

    # Save PNG
    print(f"Saving high-res composite image as: {output_png}")
    canvas.save(output_png, dpi=(300, 300), quality=95)
    
    # Save PDF
    print(f"Saving PDF layout as: {output_pdf}")
    canvas.save(output_pdf, "PDF", resolution=300.0)
    print("Export Complete!")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Manuscript Visual Layout Compiler.")
    parser.add_argument("--dir", default=".", help="Directory containing raw curves.")
    parser.add_argument("--out_png", default="ROC_AUC_Manuscript_Grid_v5.tiff", help="PNG path.")
    parser.add_argument("--out_pdf", default="ROC_AUC_Manuscript_Grid_v5.pdf", help="PDF path.")
    args = parser.parse_args()
    
    combine_images_vertical_5x3(args.dir, args.out_png, args.out_pdf)
