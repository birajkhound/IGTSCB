import os
import glob
from PIL import Image, ImageDraw, ImageFont

def get_default_font(size=20, bold=False):
    """Attempt to load a standard sans-serif font from the system, falling back to default."""
    try:
        font_names = []
        if bold:
            font_names = [
                "arialbd.ttf", "Arial-Bold.ttf", "Helvetica-Bold.ttf",
                "LiberationSans-Bold.ttf", "DejaVuSans-Bold.ttf"
            ]
        font_names += [
            "arial.ttf", "Arial.ttf", 
            "Helvetica.ttf", "helvetica.ttf",
            "LiberationSans-Regular.ttf",
            "DejaVuSans.ttf"
        ]
        for font_name in font_names:
            try:
                return ImageFont.truetype(font_name, size)
            except IOError:
                continue
        return ImageFont.load_default()
    except Exception:
        return ImageFont.load_default()

def draw_vertical_text(canvas, text, font, position, fill="black"):
    """
    Draw vertical text (rotated 90 degrees counter-clockwise) onto the canvas.
    position: (x, y) coordinates for the top-left corner of the rotated text block.
    """
    # Create a temp image to draw the text horizontally
    temp_draw = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
    
    # Calculate text width and height
    text_w = int(temp_draw.textlength(text, font=font))
    try:
        bbox = font.getbbox("A")
        text_h = bbox[3] - bbox[1]
    except Exception:
        text_h = 24  # reasonable fallback
        
    # Create transparent image with some padding to prevent clipping
    pad_w, pad_h = 24, 24
    text_img = Image.new("RGBA", (text_w + pad_w, text_h + pad_h), (255, 255, 255, 0))
    d = ImageDraw.Draw(text_img)
    d.text((pad_w // 2, pad_h // 2), text, fill=fill, font=font)
    
    # Rotate 90 degrees counter-clockwise (which is 90 degrees in PIL)
    rotated_img = text_img.rotate(90, expand=True)
    
    # Paste onto canvas using alpha channel as mask
    canvas.paste(rotated_img, position, rotated_img)

def combine_images():
    print("="*85)
    print("  GENOMIC & PROTEOMIC CLASSIFICATION PERFORMANCE COMBINER (5x3 Grid - v12)")
    print("="*85)
    
    # 1. Define rows (compositional biases) mapped to letters A, B, C, D, E with explicit format
    rows = [
        {"label_bias": "A. Dinucleotide Usage Bias (DUB)", "keyword": "Dinucleotides", "letter": "A"},
        {"label_bias": "B. Codon Usage Bias (CUB)", "keyword": "codons", "letter": "B"},
        {"label_bias": "C. Codon Pair Usage Bias (CPUB)", "keyword": "codon pairs", "letter": "C"},
        {"label_bias": "D. Amino Acid Usage Bias (AAUB)", "keyword": "amino acids", "letter": "D"},
        {"label_bias": "E. Amino Acid Pair Usage Bias (AAPUB)", "keyword": "amino acid pairs", "letter": "E"}
    ]
    
    # Define columns (classes / temperature comparisons) mapped to numbers 1, 2, 3
    cols = [
        {"label": "1. Psychrophiles vs Mesophiles", "keyword": "Psychrophilic and Mesophilic", "num": "1"},
        {"label": "2. Mesophiles vs Thermophiles", "keyword": "Mesophilic and Thermophilic", "num": "2"},
        {"label": "3. Thermophiles vs Psychrophiles", "keyword": "Thermophilic and Psychrophilic", "num": "3"}
    ]
    
    # Find all image files in the directory
    search_path = "/workspace/scratch/mock_images" if os.path.exists("/workspace/scratch/mock_images") else "."
    all_files = glob.glob(os.path.join(search_path, "*.tiff")) + \
                glob.glob(os.path.join(search_path, "*.png")) + \
                glob.glob(os.path.join(search_path, "*.jpg"))
                
    all_files += glob.glob("*.tiff") + glob.glob("*.png") + glob.glob("*.jpg")
    all_files = list(set(all_files)) # deduplicate
    
    print(f"[*] Found {len(all_files)} image files to scan.")
    
    # 2. Map files based on matching logic
    grid_files = {}
    missing_files = []
    
    for r_idx, r in enumerate(rows):
        for c_idx, c in enumerate(cols):
            matched_file = None
            for f in all_files:
                f_basename = os.path.basename(f)
                f_lower = f_basename.lower()
                # Check temperature comparison
                if c["keyword"].lower() not in f_lower:
                    continue
                
                # Check composition category with strict exclusions
                if r["keyword"] == 'amino acid pairs':
                    if 'amino acid pairs' in f_lower:
                        matched_file = f
                        break
                elif r["keyword"] == 'amino acids':
                    if 'amino acids' in f_lower and 'amino acid pairs' not in f_lower:
                        matched_file = f
                        break
                elif r["keyword"] == 'codon pairs':
                    if 'codon pairs' in f_lower:
                        matched_file = f
                        break
                elif r["keyword"] == 'codons':
                    if 'codons' in f_lower and 'codon pairs' not in f_lower:
                        matched_file = f
                        break
                elif r["keyword"] == 'Dinucleotides':
                    if 'dinucleotides' in f_lower:
                        matched_file = f
                        break
            
            if matched_file:
                grid_files[(r_idx, c_idx)] = matched_file
            else:
                expected_desc = f"Row: {r['label_bias']} | Column: {c['label']}"
                missing_files.append(expected_desc)
                
    if missing_files:
        print("\n[!] ERROR: Could not map all 15 plots. The following cells are missing:")
        for missing in missing_files:
            print(f"    - {missing}")
        print("\n[i] Please verify that your files are named exactly as shown in your notebook sources.")
        return False
        
    print("[+] Successfully mapped all 15 images to the 5x3 grid.")
    
    # 3. Read sample image to get dimensions
    sample_img_path = grid_files[(0, 0)]
    with Image.open(sample_img_path) as img:
        orig_width, orig_height = img.size
        print(f"[*] Subplot Base Dimensions: {orig_width}x{orig_height} pixels")
        
    # Crop out the right legend area (typically 80% left is plot, 20% right is legend)
    plot_crop_ratio = 0.80
    cropped_plot_width = int(orig_width * plot_crop_ratio)
    legend_width = orig_width - cropped_plot_width
    
    # 4. Canvas dimension configuration with decreased distance on left
    margin_left = 330        # Shifted slightly right to 330 to support larger spacings
    margin_top = 220         # Top margin for Column titles and main global title
    margin_bottom = 200      # Bottom margin for horizontal X-axis label
    spacing_x = 130          # Horizontal spacing between columns
    spacing_y = 135          # Vertical spacing between rows
    legend_padding = 90      # Gap between grid and unified legend on the right
    
    total_grid_width = (cropped_plot_width * 3) + (spacing_x * 2)
    total_grid_height = (orig_height * 5) + (spacing_y * 4)
    
    final_width = margin_left + total_grid_width + legend_padding + legend_width + 50
    final_height = margin_top + total_grid_height + margin_bottom
    
    print(f"[*] Composite Canvas Dimensions: {final_width}x{final_height} pixels")
    
    # Create the base canvas
    canvas = Image.new("RGB", (final_width, final_height), "white")
    draw = ImageDraw.Draw(canvas)
    
    # Load adaptive increased fonts for maximum clarity
    font_main_title = get_default_font(64, bold=True)
    font_axis_labels = get_default_font(46, bold=True)
    font_grid_headers = get_default_font(44, bold=True)
    font_row_desc_large = get_default_font(44, bold=True) # Rotated vertical row labels
    font_panel_labels = get_default_font(40, bold=True)   # Bold subplot labels
    
    # 5. Extract and paste a single unified legend on the far right
    print("[*] Extracting unified legend...")
    legend_img = None
    with Image.open(grid_files[(0, 2)]) as img:
        # Crop the legend area from the top-right plot
        legend_img = img.crop((cropped_plot_width, 0, orig_width, orig_height))
        
    legend_x = margin_left + total_grid_width + legend_padding
    legend_y = margin_top + (total_grid_height // 2) - (orig_height // 2)
    canvas.paste(legend_img, (legend_x, legend_y))
    print("[+] Unified legend placed on the far right.")
    
    # 6. Stitch images, crop legends, and add panel labels
    print("[*] Stitching 5x3 grid...")
    for r_idx, r in enumerate(rows):
        # Calculate row Y coordinates
        row_y_top = margin_top + (r_idx * (orig_height + spacing_y))
        row_y_center = row_y_top + (orig_height // 2)
        
        # Draw vertical row description (rotated 90 degrees counter-clockwise) in black
        # Centered horizontally at x=160 (shifted right from 90 to decrease distance to grid and increase distance from Y-axis label at x=25)
        label_text = r["label_bias"]
        
        # Create temporary horizontal image for rotated label
        temp_draw_label = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
        label_w = int(temp_draw_label.textlength(label_text, font=font_row_desc_large))
        try:
            bbox_l = font_row_desc_large.getbbox("A")
            label_h = bbox_l[3] - bbox_l[1]
        except Exception:
            label_h = 36
            
        pad_w, pad_h = 24, 24
        label_img_temp = Image.new("RGBA", (label_w + pad_w, label_h + pad_h), (255, 255, 255, 0))
        d_label = ImageDraw.Draw(label_img_temp)
        d_label.text((pad_w // 2, pad_h // 2), label_text, fill="black", font=font_row_desc_large)
        
        # Rotate 90 degrees counter-clockwise and paste
        rotated_label = label_img_temp.rotate(90, expand=True)
        label_paste_x = 160 - (rotated_label.width // 2)
        label_paste_y = row_y_center - (rotated_label.height // 2)
        canvas.paste(rotated_label, (label_paste_x, label_paste_y), rotated_label)
            
        for c_idx, c in enumerate(cols):
            img_path = grid_files[(r_idx, c_idx)]
            with Image.open(img_path) as img:
                # Crop the main plot area (exclude redundant legend)
                plot_area = img.crop((0, 0, cropped_plot_width, orig_height))
                
                # Calculate coordinates
                paste_x = margin_left + (c_idx * (cropped_plot_width + spacing_x))
                paste_y = row_y_top
                
                # Paste onto canvas
                canvas.paste(plot_area, (paste_x, paste_y))
                
                # Draw the panel number (e.g., "(A1)") cleanly shifted to the left of each subplot
                # Centered perfectly in the white gutter at x = paste_x - 65
                panel_label = f"({r['letter']}{c['num']})"
                p_label_w = draw.textlength(panel_label, font=font_panel_labels)
                p_label_x = paste_x - 65 - (p_label_w // 2)
                p_label_y = paste_y + 20
                draw.text((p_label_x + 20, p_label_y), panel_label, fill="black", font=font_panel_labels)
                
    # 7. Draw Column headers at the top
    print("[*] Writing column titles...")
    for c_idx, c in enumerate(cols):
        col_x_center = margin_left + (c_idx * (cropped_plot_width + spacing_x)) + (cropped_plot_width // 2)
        
        # Stacked description "1. Psychrophiles vs Mesophiles" etc. in black
        text_w = draw.textlength(c["label"], font=font_grid_headers)
        draw.text((col_x_center - (text_w // 2), margin_top - 60), c["label"], fill="black", font=font_grid_headers)
        
    # 8. Add X and Y axis labels and main Title
    print("[*] Adding axis labels and main title...")
    
    # Main Title (Black)
    title_text = "Feature Selection Performance Curve"
    title_w = draw.textlength(title_text, font=font_main_title)
    grid_center_x = margin_left + (total_grid_width // 2)
    draw.text((grid_center_x - (title_w // 2), 40), title_text, fill="black", font=font_main_title)
    
    # X-axis Label (Black)
    x_label_text = "percentage of features"
    x_label_w = draw.textlength(x_label_text, font=font_axis_labels)
    draw.text((grid_center_x - (x_label_w // 2), final_height - 110), x_label_text, fill="black", font=font_axis_labels)
    
    # Y-axis Label (Vertical, Black)
    y_label_text = "ROC AUC values"
    y_label_y_start = margin_top + (total_grid_height // 2) - 150
    draw_vertical_text(canvas, y_label_text, font_axis_labels, (25, y_label_y_start), fill="black")
    
    # 9. Save outputs
    output_tiff = "combined_performance_grid_v12.tiff"
    output_pdf = "combined_performance_grid_v12.pdf"
    
    print(f"[*] Saving high-res TIFF: '{output_tiff}'...")
    canvas.save(output_tiff, compression="tiff_lzw")
    
    print(f"[*] Saving high-quality PDF: '{output_pdf}'...")
    canvas.save(output_pdf, format="PDF")
    
    print("="*85)
    print(" SUCCESS: Combination process complete!")
    print(f" Created: '{output_tiff}'")
    print(f" Created: '{output_pdf}'")
    print("="*85)
    return True

if __name__ == "__main__":
    try:
        combine_images()
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"\n[!] Unexpected Error: {e}")
        print("[i] Ensure Python's 'Pillow' library is installed: pip install pillow")
