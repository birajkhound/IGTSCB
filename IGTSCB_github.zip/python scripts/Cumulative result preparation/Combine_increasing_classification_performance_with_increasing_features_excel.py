import os
import glob
import re
import pandas as pd

def process_single_excel(file_path):
    """
    Reads an Excel file with multiple sheet percentages (e.g., '10.0% features')
    and consolidates performance metrics grouped by classifier.
    """
    xls = pd.ExcelFile(file_path)
    
    # Store metrics per classifier
    classifier_data = {}
    metrics = [
        'accuracy', 'precision', 'recall', 'f1 score', 
        'roc_auc_score', 'jaccard_weighted', 'matthews_corrcoef'
    ]
    
    for sheet_name in xls.sheet_names:
        # Extract numerical percentage from sheet name (e.g., '10.0% features' -> 10)
        match = re.search(r'([\d\.]+)', sheet_name)
        feat_pct = int(float(match.group(1))) if match else sheet_name
        
        df = pd.read_excel(xls, sheet_name=sheet_name)
        
        for _, row in df.iterrows():
            clf = row['classifiers']
            if clf not in classifier_data:
                classifier_data[clf] = []
            
            entry = {'% of features': feat_pct}
            for metric in metrics:
                entry[metric] = row[metric] if metric in df.columns else None
            
            classifier_data[clf].append(entry)
            
    # Reorganize rows in sequence grouped by classifier
    final_rows = []
    for clf, rows in classifier_data.items():
        # Sort feature percentages in ascending order (10, 20, 30, ...)
        rows_sorted = sorted(rows, key=lambda x: x['% of features'])
        
        for idx, r in enumerate(rows_sorted):
            row_dict = {
                'classifiers': clf if idx == 0 else '',  # Classifier name appears on the 1st row of each group
                '% of features': r['% of features']
            }
            for metric in metrics:
                row_dict[metric] = r[metric]
            final_rows.append(row_dict)
            
    return pd.DataFrame(final_rows)


def batch_process_excel_files(input_dir, output_dir):
    """
    Processes all Excel files in input_dir and saves processed files to output_dir.
    """
    os.makedirs(output_dir, exist_ok=True)
    
    # Locate all .xlsx files in the input folder
    excel_files = glob.glob(os.path.join(input_dir, "*.xlsx"))
    
    if not excel_files:
        print(f"No Excel files found in '{input_dir}'")
        return

    print(f"Found {len(excel_files)} file(s) to process...\n")
    
    for file_path in excel_files:
        file_name = os.path.basename(file_path)
        
        # Skip files that are already result files
        if file_name.startswith("result_"):
            continue
            
        print(f"Processing: {file_name} ...")
        
        # Transform data
        df_result = process_single_excel(file_path)
        
        # Save output file
        output_name = f"result_{file_name}"
        output_path = os.path.join(output_dir, output_name)
        
        df_result.to_excel(output_path, index=False)
        print(f" Saved to: {output_path}")

    print("\nBatch processing completed successfully!")


if __name__ == "__main__":
    # Specify your input folder containing files like q1.xlsx, q2.xlsx, etc.
    INPUT_FOLDER = "C:\\Users\\HP\\Downloads\\CB\\Input folder\\"
    OUTPUT_FOLDER = "C:\\Users\\HP\\Downloads\\CB\\Output folder\\"
    
    batch_process_excel_files(INPUT_FOLDER, OUTPUT_FOLDER)